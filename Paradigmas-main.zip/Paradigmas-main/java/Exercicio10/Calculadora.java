package Exercicio10;

public class Calculadora {
    public static int soma(int n1, int n2) {
        return n1 + n2;
    }
    public static int soma(int n1, int n2, int n3) {
        return n1 + n2 + n3;
    }
}
