package Exercicio11;

public class Funcionario {
    private String nome, cargo;

    public Funcionario(String nome, String cargo) {
        this.nome = nome;
        this.cargo = cargo;
    }

    public void calcularSalario() {
    }
}
