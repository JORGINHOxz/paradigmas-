package Exercicio12;

public class funcoes {
    public static double somaValorProdutos(Produto p1, Produto p2){
        return p1.getValor() + p2.getValor();
    }
}
