package Exercicio15;

public class SaldoInsuficienteException extends Exception {
    public SaldoInsuficienteException(String mensagem){
        super(mensagem);
    }

}
