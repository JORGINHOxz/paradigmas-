package Exercicio9;

public class Interfaces {
    public interface Imprimivel {
        void imprimir();
    }
}
