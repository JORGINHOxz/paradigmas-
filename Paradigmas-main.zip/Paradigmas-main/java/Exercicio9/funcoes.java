package Exercicio9;

public class funcoes {
    public static void imprimirDocumento(Interfaces.Imprimivel doc){
        doc.imprimir();
    }
}
