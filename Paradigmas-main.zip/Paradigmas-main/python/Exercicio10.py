class Calculadora:
    def soma2(n1, n2):
        return n1 + n2
    
    def soma3(n1, n2, n3):
        return n1 + n2 + n3
    

print(Calculadora.soma2(5, 5))
print(Calculadora.soma3(5, 5, 5))
    